/* Межгород Трансфер — сайт и приложение для Android: тумблер темы, выдвижное меню,
   звонок и карта в заказе, класс авто кнопками,
   подписи даты и времени в полях, вопросы по нажатию. */
(function () {
  var html = document.documentElement;
  var KEY = 'mtTheme';
  var SVG = '<svg viewBox="0 0 24 24" aria-hidden="true">';
  var MOON = SVG + '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5z"/></svg>';
  var SUN = SVG + '<circle cx="12" cy="12" r="4.2"/><path d="M12 1.8v2.6M12 19.6v2.6M1.8 12h2.6M19.6 12h2.6M4.8 4.8l1.8 1.8M17.4 17.4l1.8 1.8M4.8 19.2l1.8-1.8M17.4 6.6l1.8-1.8"/></svg>';
  var PHONE = SVG + '<path d="M6.5 3.5c.6-.3 1.3-.1 1.6.5l1.3 2.4c.3.5.2 1.1-.2 1.5l-1 1c.8 1.9 2.3 3.4 4.2 4.2l1-1c.4-.4 1-.5 1.5-.2l2.4 1.3c.6.3.8 1 .5 1.6l-.9 1.7c-.3.6-1 1-1.7.9-5-1-9-5-10-10-.1-.7.3-1.4.9-1.7l1.7-.9z"/></svg>';
  var each = function (list, fn) { Array.prototype.forEach.call(list, fn); };
  var themed = [];                               // кому перекраситься при смене темы

  function saved() {
    try { var t = localStorage.getItem(KEY); return t === 'light' || t === 'dark' ? t : ''; } catch (e) { return ''; }
  }

  function setTheme(t, remember) {
    html.setAttribute('data-theme', t);
    var meta = document.querySelector('meta[name=theme-color]');
    if (meta) meta.setAttribute('content', t === 'light' ? '#E8EFF8' : '#070B1C');
    if (remember) try { localStorage.setItem(KEY, t); } catch (e) {}
    themed.forEach(function (fn) { fn(); });
  }
  var dark = function () { return html.getAttribute('data-theme') !== 'light'; };

  // Тумблер темы в шапке: одна кнопка, значок ☾ / ☀ — текущая тема. Пока человек
  // сам не выбрал — тема как в телефоне и меняется вместе с ней; выбор запоминается.
  function themeSwitch(menuBtn) {
    var ts = document.createElement('button');
    ts.type = 'button';
    ts.className = 'ts';
    ts.setAttribute('aria-label', 'Сменить тему');
    ts.innerHTML = MOON + SUN;
    menuBtn.parentNode.insertBefore(ts, menuBtn);
    ts.addEventListener('click', function () { setTheme(dark() ? 'light' : 'dark', true); });
    setTheme(saved() || html.getAttribute('data-theme') || 'dark');
    var mq = matchMedia('(prefers-color-scheme: light)');
    var follow = function () { if (!saved()) setTheme(mq.matches ? 'light' : 'dark'); };
    if (mq.addEventListener) mq.addEventListener('change', follow);
    else if (mq.addListener) mq.addListener(follow);
  }

  // Меню выезжает справа под шапкой. Открывает его прежняя toggleMobileNav(),
  // здесь — затемнение, закрытие касанием мимо, контакты и отметка страницы.
  function menu(btn) {
    var nav = document.getElementById('mobile-nav');
    if (!nav) return;
    document.body.appendChild(nav);              // из шапки: у шапки-стекла свой слой
    var scrim = document.createElement('div');
    scrim.className = 'app-scrim';
    document.body.insertBefore(scrim, nav);
    var top = document.querySelector('.topbar');
    if (top) {
      var box = document.createElement('div');
      box.className = 'app-menu-contacts';
      each(top.querySelectorAll('a'), function (a) { box.appendChild(a.cloneNode(true)); });
      nav.appendChild(box);
    }
    each(nav.children, function (a) {
      if (a.tagName === 'A' && !a.hash && a.pathname === location.pathname) a.setAttribute('aria-current', 'page');
    });
    btn.setAttribute('aria-controls', 'mobile-nav');
    var sync = function () {
      var open = nav.classList.contains('open');
      html.classList.toggle('nav-open', open);
      btn.setAttribute('aria-expanded', String(open));
    };
    new MutationObserver(sync).observe(nav, { attributes: true, attributeFilter: ['class'] });
    sync();
    scrim.addEventListener('click', function () { nav.classList.remove('open'); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') nav.classList.remove('open'); });
  }

  function classChips() {
    var sel = document.getElementById('ord-carclass');
    if (!sel) return;
    var rates = {};
    each(document.querySelectorAll('.class-card'), function (c) {
      var h = c.querySelector('h3'), r = c.querySelector('.rate');
      if (h && r) rates[h.textContent.trim()] = r.textContent.trim();
    });
    var box = document.createElement('div');
    box.className = 'app-chips';
    box.setAttribute('role', 'group');
    box.setAttribute('aria-label', 'Класс авто');
    each(sel.options, function (o) {
      var b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('data-v', o.value);
      var name = document.createElement('b');
      name.textContent = o.text;
      b.appendChild(name);
      if (rates[o.text.trim()]) {
        var rate = document.createElement('span');
        rate.textContent = rates[o.text.trim()];
        b.appendChild(rate);
      }
      box.appendChild(b);
    });
    sel.parentNode.insertBefore(box, sel.nextSibling);
    sel.parentNode.classList.add('app-wide');
    var sync = function () {
      each(box.children, function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-v') === sel.value)); });
    };
    box.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || b.getAttribute('data-v') === sel.value) return;
      sel.value = b.getAttribute('data-v');
      sel.dispatchEvent(new Event('change', { bubbles: true }));   // цена и пассажиры — как при выборе в списке
      sync();
    });
    // Класс меняют и без кнопок: 5+ пассажиров — минивэн, после отправки форма сбрасывается
    var later = function () { setTimeout(sync, 0); };
    sel.addEventListener('change', later);
    var pass = document.getElementById('ord-passengers');
    if (pass) pass.addEventListener('change', later);
    if (sel.form) sel.form.addEventListener('reset', later);
    sync();
  }

  // Заказ по телефону — в конце блока заказа, под «Отправить заявку». Номер — тот же,
  // что в шапке сайта; это обычная ссылка tel:, Метрика считает нажатия, как и раньше.
  function callButton() {
    var card = document.querySelector('.calc-card');
    var tel = document.querySelector('.topbar a[href^="tel:"]');
    if (!card || !tel) return;
    var a = document.createElement('a');
    a.className = 'app-call';
    a.href = tel.getAttribute('href');
    a.innerHTML = '<span class="app-call-ico">' + PHONE + '</span><span class="app-call-txt"><small>Заказать по телефону</small><b></b></span>';
    a.querySelector('b').textContent = tel.textContent.trim();
    card.appendChild(a);
  }

  // Дата и время: подпись стоит внутри поля, пока в нём пусто
  function fieldLabels() {
    each(document.querySelectorAll('.in-field input'), function (el) {
      var f = el.parentNode;
      var sync = function () { f.classList.toggle('app-filled', el.value !== '' || el.validity.badInput); };
      ['input', 'change', 'blur'].forEach(function (ev) { el.addEventListener(ev, sync); });
      if (el.form) el.form.addEventListener('reset', function () { setTimeout(sync, 0); });
      window.addEventListener('pageshow', sync);
      sync();
    });
  }

  // Карта — внизу заказа, перед ценой. Схема Яндекса (JS API 3.0) — ровные цвета
  // под тему приложения, маршрут — неоновой линией. Не загрузилась — прежняя карта (2.1).
  var LAND = ['landscape', 'land', 'landcover', 'vegetation', 'national_park', 'urban_area', 'residential',
              'industrial', 'park', 'cemetery', 'medical', 'sports_ground', 'beach', 'construction_site'];
  function mapLook() {                             // без рельефа, «зелени», значков и номеров дорог
    var c = dark()
      ? { land: '#141A2D', city: '#1A2138', water: '#0A1430', road: '#25304F', main: '#33467A', edge: '',
          border: '#3A3F66', text: '#7F8AAD', halo: '#0A0F22', town: '#C9D3EA' }
      : { land: '#EEF2F8', city: '#E3E9F2', water: '#C4DDF3', road: '#FFFFFF', main: '#D3E2F6', edge: '#D7DFEA',
          border: '#B9C3D6', text: '#6A7896', halo: '#F4F7FB', town: '#2A3550' };
    var rule = function (tags, el, st) {
      var r = { stylers: [st] };
      if (tags) r.tags = { any: tags };
      if (el) r.elements = el;
      return r;
    };
    return [
      rule(LAND, 'geometry', { color: c.land }),
      rule(['urban_area', 'residential', 'industrial'], 'geometry', { color: c.city }),
      rule(['water'], 'geometry', { color: c.water }),
      rule(['terrain', 'bathymetry', 'poi', 'transit'], null, { visibility: 'off' }),
      rule(['road'], 'geometry.fill', { color: c.road }),
      rule(['road_1', 'road_2'], 'geometry.fill', { color: c.main }),
      rule(['road'], 'geometry.outline', c.edge ? { color: c.edge } : { visibility: 'off' }),
      rule(['country', 'region'], 'geometry', { color: c.border }),
      rule(null, 'label.text.fill', { color: c.text }),
      rule(null, 'label.text.outline', { color: c.halo }),
      rule(['locality'], 'label.text.fill', { color: c.town }),
      rule(['road'], 'label', { visibility: 'off' })
    ];
  }

  function routeMap() {
    var M = window.mtransMap, box = document.getElementById('route-map');
    if (!M || !box) return;
    var est = document.getElementById('price-estimate');
    if (est) est.parentNode.insertBefore(box, est);
    var fromEl = document.getElementById('ord-from'), toEl = document.getElementById('ord-to');
    var Y = null, map = null, scheme = null, pts = null, line = null, drawn = [], old = false;

    function fallback() {
      if (old) return;
      old = true;
      if (map) try { map.destroy(); } catch (e) {}
      map = null;
      box.innerHTML = '';
      box.classList.add('map-old');
      window.mtransRouteDraw = M.draw;
      M.start();
      if (pts) M.draw(pts);
    }

    // Неоновая линия: яркая середина и два слоя свечения; концы — светящиеся точки.
    // Названия городов не дублируем — они есть на самой карте.
    function paint() {
      if (!map) return;
      drawn.forEach(function (o) { map.removeChild(o); });
      drawn = [];
      if (!line) return;
      var c = dark() ? '#6FE7F7' : '#13ABD6';
      drawn.push(new Y.YMapFeature({
        geometry: { type: 'LineString', coordinates: line },
        style: { stroke: [{ color: c, width: 3.5 }, { color: c + '59', width: 8 }, { color: c + '26', width: 16 }] }
      }));
      [[line[0], 'a'], [line[line.length - 1], 'b']].forEach(function (m) {
        var el = document.createElement('div');
        el.className = 'app-pin app-pin-' + m[1];
        drawn.push(new Y.YMapMarker({ coordinates: m[0] }, el));
      });
      drawn.forEach(function (o) { map.addChild(o); });
    }

    // Линия — по дорогам, как у бота (OSRM и Верхний Ларс — из кода сайта)
    function draw() {
      var c = pts;
      line = null;
      paint();
      if (!c || !map) return;
      var a = (fromEl && fromEl.value || '').trim(), b = (toEl && toEl.value || '').trim();
      M.osrm(c[0], c[1], M.transcaucasus(a) !== M.transcaucasus(b))
        .catch(function () { return [c[0], c[1]]; })
        .then(function (geom) {
          if (pts !== c || !map) return;                      // пока ждали, маршрут сменился
          line = geom.map(function (p) { return [p[1], p[0]]; });   // в 3.0 — [долгота, широта]
          paint();
          var lo = [180, 90], hi = [-180, -90];
          line.forEach(function (p) {
            lo = [Math.min(lo[0], p[0]), Math.min(lo[1], p[1])];
            hi = [Math.max(hi[0], p[0]), Math.max(hi[1], p[1])];
          });
          // Запас снизу больше: внизу карты кнопка и логотип Яндекса
          var w = hi[0] - lo[0], h = hi[1] - lo[1];
          var side = Math.max(w * 0.3, 0.05), top = Math.max(h * 0.25, 0.05), bottom = Math.max(h * 0.55, 0.12);
          map.setLocation({ bounds: [[lo[0] - side, lo[1] - bottom], [hi[0] + side, hi[1] + top]], duration: 300 });
        });
    }

    window.mtransRouteDraw = function (p) { pts = p || null; draw(); };
    themed.push(function () {
      if (!map) return;
      map.update({ theme: dark() ? 'dark' : 'light' });
      try { scheme.update({ customization: mapLook() }); } catch (e) {}
      paint();
    });

    var sc = document.createElement('script');
    sc.src = 'https://api-maps.yandex.ru/v3/?apikey=' + encodeURIComponent(M.key) + '&lang=ru_RU';
    sc.onerror = fallback;
    sc.onload = function () {
      if (!window.ymaps3) { fallback(); return; }
      var wait = setTimeout(fallback, 15000);                 // молчит — скорее всего, отказ по ключу
      ymaps3.ready.then(function () {
        clearTimeout(wait);
        if (old) return;
        try {
          Y = ymaps3;
          scheme = new Y.YMapDefaultSchemeLayer({ customization: mapLook() });
          map = new Y.YMap(box, { location: { center: [41.0, 46.0], zoom: 5 }, mode: 'vector', theme: dark() ? 'dark' : 'light' },
                           [scheme, new Y.YMapDefaultFeaturesLayer({})]);
          draw();
        } catch (e) { fallback(); }
      }, fallback);
    };
    document.head.appendChild(sc);
  }

  // Частые вопросы — ответ по нажатию, открыт один
  function faq() {
    var qs = document.querySelectorAll('.faq-item > h3');
    each(qs, function (h) {
      h.setAttribute('role', 'button');
      h.setAttribute('tabindex', '0');
      h.setAttribute('aria-expanded', 'false');
    });
    var toggle = function (h) {
      var item = h.parentNode, open = !item.classList.contains('open');
      each(qs, function (q) { q.parentNode.classList.remove('open'); q.setAttribute('aria-expanded', 'false'); });
      item.classList.toggle('open', open);
      h.setAttribute('aria-expanded', String(open));
    };
    document.addEventListener('click', function (e) {
      var h = e.target.closest('.faq-item > h3');
      if (h) toggle(h);
    });
    document.addEventListener('keydown', function (e) {
      var h = e.target.closest && e.target.closest('.faq-item > h3');
      if (h && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); toggle(h); }
    });
  }

  function init() {
    var btn = document.querySelector('.mobile-menu-btn');
    if (btn) {
      themeSwitch(btn);
      menu(btn);
    }
    callButton();
    fieldLabels();
    routeMap();
    classChips();
    faq();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
